/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MOB1014_Lab4;


public class Lab4Bai2 {
    public static void main(String[] args) {
        SanPham sp1 = new SanPham();
        SanPham sp2 = new SanPham ();
        sp1.nhap();
        sp2.nhap();
        System.out.println("------------------");
        sp1.xuat();
        sp2.xuat();
    }
}
