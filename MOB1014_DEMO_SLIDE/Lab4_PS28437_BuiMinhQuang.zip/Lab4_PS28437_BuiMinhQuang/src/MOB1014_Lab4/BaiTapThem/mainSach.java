
package MOB1014_Lab4.BaiTapThem;


public class mainSach {
    public static void main(String[] args) {
        Sach sach1 = new Sach();
        sach1.nhap();
        sach1.xuat();
    }
}

