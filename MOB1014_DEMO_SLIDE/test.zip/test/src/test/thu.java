/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

public class thu {

    public static void main(String[] args) {
        QuanLy moi = new QuanLy();
        moi.nhap();
        moi.xuat();
        moi.xuatSachLapTrinh();
    }
}
