/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai3;

public class Main {
    public static void main(String[] args) {
        DanhSachSinhVien ddsv = new DanhSachSinhVien();
        ddsv.nhap();
        ddsv.xuat();
    }
}