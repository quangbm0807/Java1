/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab7;


public class Lab7Bai1 {
    public static void main(String[] args) {
        ChuNhat cn = new ChuNhat();
        Vuong vuong = new Vuong();
        cn.nhap();
        cn.xuat();
        vuong.nhap();
        vuong.xuat();
    }
}
