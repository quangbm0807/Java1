/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package S5_MangNangCao;

/**
 *
 * @author buimi
 */
public class MainMang {
    public static void main(String[] args) {
        S5_MangNangCao man = new S5_MangNangCao();
        man.nhapmang();
        man.xuatmang();
        man.sapxep();
        man.daonguoc();
        man.themphantu();
        man.xoaphantu();
        man.xoavareturn();
        man.thaydoi();
        man.truyxuat();
        man.sophantu();
        man.vitri();
    }
}
